# Yusuf Sarigul Resume Website

This repository contains a personal resume website built with HTML and CSS.